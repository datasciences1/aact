library(shiny)

# Define UI for application
ui <- fluidPage(
   
  # Application title
  titlePanel("Modelisation output display"),
   
  # Sidebar with a slider input for number of bins 
  sidebarLayout(
    sidebarPanel(
      selectInput("method", "Choose your Method:", choices = c('cart'='cart','glm'='glm','glmnet'='glmnet','Neural Net'='nn','Random Forest'='rf','xgboost'='xgboost') ),

      conditionalPanel("input.method=='nn'",     radioButtons("fig1","Choose your Output:", choices=c("Complexity Model"="cm","Confusion Matrix"="confmtx","Result Training"="rest","Summary Model"="smy")) ),
      conditionalPanel("input.method=='xgboost'",radioButtons("fig2","Choose your Output:", choices=c("Complexity Model"="cm","Confusion Matrix"="confmtx","Result Training"="rest","Summary Model"="smy")) ),
      conditionalPanel("input.method=='cart'",   radioButtons("fig3","Choose your Output:", choices=c("Complexity Model"="cm","Confusion Matrix"="confmtx","Summary Model"="smy")) ),
      conditionalPanel("input.method=='glm'",    radioButtons("fig4","Output:", choices=c("Summary Model"="smy")) ),
      conditionalPanel("input.method=='glmnet'", radioButtons("fig5","Choose your Output:", choices=c("Complexity Model"="cm","Confusion Matrix"="confmtx","Result Training"="rest","Summary Model"="smy")) ),
      conditionalPanel("input.method=='rf'",     radioButtons("fig6","Choose your Output:", choices=c("Complexity Model"="cm","Confusion Matrix"="confmtx","Result Training"="rest","Summary Model"="smy")) )
      
    ),
    # Show output
    mainPanel(
      imageOutput("image")

    )
  )
)


# Define server logic required
server <- function(input, output) {
  
  outputOptions(output, suspendWhenHidden=FALSE)
  
  output$image <- renderImage({
    if(input$method=='xgboost' && input$fig2=='cm'){
      outfile <- 'xgboost/complexity_m.png'
      list(src=outfile, contentType = 'image/png', width=1000, height=500)
    }
    else if(input$method=='xgboost' && input$fig2=='confmtx'){
      outfile <- 'xgboost/mat_conf.png'
      list(src=outfile, contentType = 'image/png', width=1000, height=500)
    }
    else if(input$method=='xgboost' && input$fig2=='rest'){
      outfile <- 'xgboost/res_train.png'
      list(src=outfile, contentType = 'image/png', width=1000, height=500)
    }
    else if(input$method=='xgboost' && input$fig2=='smy'){
      outfile <- 'xgboost/summary.png'
      list(src=outfile, contentType = 'image/png', width=1000, height=500)
    }
    else if(input$method=='cart' & input$fig3=='cm'){
      outfile <- 'cart/complexity_m.png'
      list(src=outfile, contentType = 'image/png', width=1000, height=500)
    }
    else if(input$method=='cart' & input$fig3=='confmtx'){
      outfile <- 'cart/mat_conf.png'
      list(src=outfile, contentType = 'image/png', width=1000, height=500)
    }
    else if(input$method=='cart' & input$fig3=='smy'){
      outfile <- 'cart/summary.png'
      list(src=outfile, contentType = 'image/png', width=1000, height=500)
    }
    else if(input$method=='glm' && input$fig4=='smy'){
      outfile <- 'glm/summary.png'
      list(src=outfile, contentType = 'image/png', width=1000, height=700)
    }    
    else if(input$method=='glmnet' && input$fig5=='cm'){
      outfile <- 'glmnet/complexity_m.png'
      list(src=outfile, contentType = 'image/png', width=1000, height=500)
    }
    else if(input$method=='glmnet' && input$fig5=='confmtx'){
      outfile <- 'glmnet/mat_conf.png'
      list(src=outfile, contentType = 'image/png', width=1000, height=500)
    }
    else if(input$method=='glmnet' && input$fig5=='rest'){
      outfile <- 'glmnet/res_train.png'
      list(src=outfile, contentType = 'image/png', width=1000, height=500)
    }
    else if(input$method=='glmnet' && input$fig5=='smy'){
      outfile <- 'glmnet/summary.png'
      list(src=outfile, contentType = 'image/png', width=1000, height=500)
    }
    else if(input$method=='nn' && input$fig1=='cm'){
      outfile <- 'nn/complexity_m.png'
      list(src=outfile, contentType = 'image/png', width=1000, height=500)
    }
    else if(input$method=='nn' && input$fig1=='confmtx'){
      outfile <- 'nn/mat_conf.png'
      list(src=outfile, contentType = 'image/png', width=1000, height=500)
    }
    else if(input$method=='nn' && input$fig1=='rest'){
      outfile <- 'nn/res_train.png'
      list(src=outfile, contentType = 'image/png', width=1000, height=500)
    }
    else if(input$method=='nn' && input$fig1=='smy'){
      outfile <- 'nn/summary.png'
      list(src=outfile, contentType = 'image/png', width=1000, height=400)
    }
    else if(input$method=='rf' && input$fig6=='cm'){
      outfile <- 'rf/complexity_m.png'
      list(src=outfile, contentType = 'image/png', width=1000, height=500)
    }
    else if(input$method=='rf' && input$fig6=='confmtx'){
      outfile <- 'rf/mat_conf.png'
      list(src=outfile, contentType = 'image/png', width=1000, height=500)
    }
    else if(input$method=='rf' && input$fig6=='rest'){
      outfile <- 'rf/res_train.png'
      list(src=outfile, contentType = 'image/png', width=1000, height=500)
    }
    else if(input$method=='rf' && input$fig6=='smy'){
      outfile <- 'rf/summary.png'
      list(src=outfile, contentType = 'image/png', width=1000, height=500)
    }
    
   }, deleteFile = FALSE )

}

# Run the application 
shinyApp(ui = ui, server = server)