https://rstudio-pubs-static.s3.amazonaws.com/72664_2b1ee5cd10d447e4af50a2b68ceed428.html

R packages:
-----------
sentiment
sentimentr
tm.plugin.sentiment
qdap

