Here's the original [link](http://www.rstudio.com/resources/cheatsheets/) to the cheatsheets. 
